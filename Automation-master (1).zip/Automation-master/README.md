# Automation
solution C102
